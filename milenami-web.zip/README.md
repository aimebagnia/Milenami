# Milenami - Beta (Netlify + Firebase)

This archive contains a ready-to-build Milenami web app (Vite + React + Tailwind) with:
- Firebase Auth (Email/Password)
- Firestore usage for `users`, `transporters`, `requests`
- PWA manifest and service worker

## Quick start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Set Netlify (or local) environment variables (VITE_FIREBASE_* keys) as provided by Firebase console.
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Build for production:
   ```bash
   npm run build
   ```

See the full README in the project canvas for detailed instructions on Firebase, Netlify deploy and Firestore rules.
