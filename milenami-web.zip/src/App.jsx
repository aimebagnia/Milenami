import React, { useEffect, useState } from 'react'
import { auth, db } from './firebase'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile } from 'firebase/auth'
import { collection, addDoc, getDocs } from 'firebase/firestore'

function registerSW() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').then(() => {
      console.log('Service Worker enregistré')
    }).catch(console.warn)
  }
}

export default function App () {
  const [route, setRoute] = useState('home')
  const [user, setUser] = useState(null)
  const [transporters, setTransporters] = useState([])

  useEffect(() => {
    registerSW()
    const unsub = onAuthStateChanged(auth, u => setUser(u))
    loadTransporters()
    return unsub
  }, [])

  async function loadTransporters () {
    try {
      const snap = await getDocs(collection(db, 'transporters'))
      setTransporters(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    } catch (e) { console.error(e) }
  }

  // AUTH flows
  async function handleRegister ({ name, email, password, role }) {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password)
      await updateProfile(cred.user, { displayName: name })
      await addDoc(collection(db, 'users'), { uid: cred.user.uid, name, email, role, createdAt: new Date() })
      alert('Compte créé')
      setRoute('home')
    } catch (e) { alert(e.message) }
  }

  async function handleLogin ({ email, password }) {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      setRoute('home')
    } catch (e) { alert('Connexion échouée') }
  }

  async function handleLogout () {
    await signOut(auth)
  }

  async function publishRequest (data) {
    if (!user) { alert('Connectez-vous'); setRoute('login'); return }
    try {
      await addDoc(collection(db, 'requests'), { ...data, clientId: user.uid, status: 'open', createdAt: new Date() })
      alert('Demande publiée')
      setRoute('home')
    } catch (e) { console.error(e); alert('Erreur') }
  }

  async function registerTransporter (payload) {
    try {
      await addDoc(collection(db, 'transporters'), payload)
      alert('Transporteur enregistré')
      loadTransporters()
      setRoute('list')
    } catch (e) { console.error(e); alert('Erreur') }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-md mx-auto p-4">
        {route === 'home' && (
          <div>
            <h1 className="text-2xl font-bold">Milenami</h1>
            <p className="text-sm mt-2">Platforme de déménagement - Beta</p>

            <div className="mt-4">
              {user ? (
                <div className="p-3 border rounded">
                  <div className="font-medium">{user.displayName || user.email}</div>
                  <div className="mt-2 flex gap-2">
                    <button onClick={() => setRoute('request')} className="px-3 py-2 bg-indigo-600 text-white rounded">Nouvelle demande</button>
                    <button onClick={() => setRoute('list')} className="px-3 py-2 border rounded">Transporteurs</button>
                    <button onClick={() => handleLogout()} className="px-3 py-2 border rounded">Déconnexion</button>
                  </div>
                </div>
              ) : (
                <div className="p-3 border rounded">
                  <div className="text-sm">Non connecté</div>
                  <div className="mt-2 flex gap-2">
                    <button onClick={() => setRoute('login')} className="px-3 py-2 bg-indigo-600 text-white rounded">Se connecter</button>
                    <button onClick={() => setRoute('register')} className="px-3 py-2 border rounded">Créer un compte</button>
                  </div>
                </div>
              )}
            </div>

            <section className="mt-6">
              <h3 className="font-semibold">Transporteurs</h3>
              <div className="mt-3 space-y-3">
                {transporters.length === 0 ? <div className="text-sm text-gray-500">Aucun</div> : transporters.map(t => (
                  <div key={t.id} className="p-3 border rounded flex justify-between items-center">
                    <div>
                      <div className="font-medium">{t.name}</div>
                      <div className="text-xs">{t.vehicle} • {t.city}</div>
                    </div>
                    <div className="flex gap-2">
                      <a href={`https://wa.me/${(t.phone||'').replace(/\+/g, '')}`} target="_blank" rel="noreferrer" className="px-3 py-1 bg-green-50 rounded">WhatsApp</a>
                    </div>
                  </div>
                ))}
              </div>
            </section>

          </div>
        )}

        {route === 'register' && (
          <RegisterForm onSubmit={handleRegister} onCancel={() => setRoute('home')} />
        )}

        {route === 'login' && (
          <LoginForm onLogin={handleLogin} onCancel={() => setRoute('home')} />
        )}

        {route === 'request' && (
          <RequestForm onSubmit={publishRequest} onCancel={() => setRoute('home')} />
        )}

        {route === 'list' && (
          <TransporterRegister onSubmit={registerTransporter} onCancel={() => setRoute('home')} />
        )}
      </main>
    </div>
  )
}

// Subcomponents
function RegisterForm ({ onSubmit, onCancel }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('client')
  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit({ name, email, password, role }) }} className="space-y-3">
      <h2 className="text-lg font-semibold">Créer un compte</h2>
      <input required value={name} onChange={e => setName(e.target.value)} placeholder="Nom" className="w-full p-3 border rounded" />
      <input required value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="Email" className="w-full p-3 border rounded" />
      <input required value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Mot de passe" className="w-full p-3 border rounded" />
      <div className="flex gap-2 items-center">
        <label className="text-sm">Je suis</label>
        <select value={role} onChange={e => setRole(e.target.value)} className="p-2 border rounded">
          <option value="client">Client</option>
          <option value="transporter">Transporteur</option>
        </select>
      </div>
      <div className="flex gap-2">
        <button className="flex-1 py-3 bg-indigo-600 text-white rounded">Créer</button>
        <button type="button" onClick={onCancel} className="py-3 px-3 border rounded">Annuler</button>
      </div>
    </form>
  )
}

function LoginForm ({ onLogin, onCancel }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  return (
    <form onSubmit={e => { e.preventDefault(); onLogin({ email, password }) }} className="space-y-3">
      <h2 className="text-lg font-semibold">Connexion</h2>
      <input required value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="Email" className="w-full p-3 border rounded" />
      <input required value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Mot de passe" className="w-full p-3 border rounded" />
      <div className="flex gap-2">
        <button className="flex-1 py-3 bg-indigo-600 text-white rounded">Se connecter</button>
        <button type="button" onClick={onCancel} className="py-3 px-3 border rounded">Retour</button>
      </div>
    </form>
  )
}

function RequestForm ({ onSubmit, onCancel }) {
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [date, setDate] = useState('')
  const [volume, setVolume] = useState('')
  const [notes, setNotes] = useState('')
  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit({ from, to, date, volume, notes }) }} className="space-y-3">
      <h2 className="text-lg font-semibold">Nouvelle demande</h2>
      <input required value={from} onChange={e => setFrom(e.target.value)} placeholder="Ville de départ" className="w-full p-3 border rounded" />
      <input required value={to} onChange={e => setTo(e.target.value)} placeholder="Ville d'arrivée" className="w-full p-3 border rounded" />
      <input required value={date} onChange={e => setDate(e.target.value)} type="date" className="w-full p-3 border rounded" />
      <input required value={volume} onChange={e => setVolume(e.target.value)} placeholder="Volume" className="w-full p-3 border rounded" />
      <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes" className="w-full p-3 border rounded" />
      <div className="flex gap-2">
        <button className="flex-1 py-3 bg-indigo-600 text-white rounded">Publier</button>
        <button type="button" onClick={onCancel} className="py-3 px-3 border rounded">Annuler</button>
      </div>
    </form>
  )
}

function TransporterRegister ({ onSubmit, onCancel }) {
  const [name, setName] = useState('')
  const [vehicle, setVehicle] = useState('')
  const [city, setCity] = useState('')
  const [phone, setPhone] = useState('')
  const [about, setAbout] = useState('')
  return (
    <form onSubmit={e => { e.preventDefault(); onSubmit({ name, vehicle, city, phone, about }) }} className="space-y-3">
      <h2 className="text-lg font-semibold">Inscrire un transporteur</h2>
      <input required value={name} onChange={e => setName(e.target.value)} placeholder="Nom société / déménageur" className="w-full p-3 border rounded" />
      <input value={vehicle} onChange={e => setVehicle(e.target.value)} placeholder="Type de véhicule" className="w-full p-3 border rounded" />
      <input value={city} onChange={e => setCity(e.target.value)} placeholder="Ville" className="w-full p-3 border rounded" />
      <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Téléphone" className="w-full p-3 border rounded" />
      <textarea value={about} onChange={e => setAbout(e.target.value)} placeholder="À propos" className="w-full p-3 border rounded" />
      <div className="flex gap-2">
        <button className="flex-1 py-3 bg-indigo-600 text-white rounded">Enregistrer</button>
        <button type="button" onClick={onCancel} className="py-3 px-3 border rounded">Annuler</button>
      </div>
    </form>
  )
}
